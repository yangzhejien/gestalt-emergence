# 格式塔方程验证 — 可复现包（Reproducibility Bundle）

本包用于在**独立机器**上复现「格式塔方程」主基准涌现实验：多模型分层协作架构（L3 专家集群 → L2 副脑 → L1 主脑）的集体准确率，是否稳定超越最强单体模型（7B）。

---

## 1. 环境要求

| 项目 | 规格 |
|---|---|
| 操作系统 | Windows 10/11、Linux、macOS（已在 Windows 11 验证） |
| Python | 3.13（3.10+ 应可运行） |
| Ollama | 0.32.8（或其他近期版本） |
| 内存 | ≥ 8 GB（CPU 推理 7B）；推荐 16 GB+ |
| GPU | 可选，仅加速，不改变结果 |

## 2. 安装软件依赖

```bash
pip install -r requirements.txt
# Ollama 按系统指引安装: https://ollama.com
```

> 运行依赖仅 `numpy`；其余为标准库（`urllib/json/re` 等）。报告文档生成用的 `python-docx` **不是**复现运行依赖。

## 3. 获取模型权重（必须）

权重由 Ollama 官方提供，**不随包分发**，每台机器自行拉取：

```bash
ollama pull qwen2.5:1.5b
ollama pull qwen2.5:3b
ollama pull qwen2.5:7b
```

架构固定使用：`l3=qwen2.5:1.5b`（×k）、`agg/l2=qwen2.5:3b`、`l1=qwen2.5:7b`、`verifier=qwen2.5:1.5b`。

## 4. 目录结构

```
可复现包_2026-08-11/
├── code/                  运行脚本
│   ├── verify_stage2.py       主运行器（核心）
│   ├── run_experiments.sh     ★全套启动命令总表（入口，推荐）
│   ├── check_env.sh           环境自检脚本（解压后第一步先跑）
│   ├── run_light_repro.py     作者一键编排器（硬编码本机路径，须改）
│   ├── run_controls.py        对照实验：容量 / 语言
│   ├── run_n500_clean.sh      原 N=500 主验 C 启动命令（参考）
│   ├── run_n500_demote.sh     原 消融 D 启动命令（参考）
│   ├── gen_bench.py           高难题库生成器（辅助，非主基准）
│   ├── gen_ceval_en.py        C-Eval 英文翻译
│   ├── expand_to_500.py       主基准 500 题生成器（SEED 确定性，审计用）
│   ├── clean_benchmark.py     主基准清洗器（SEED 确定性，审计用）
│   ├── view_results.py        结果 JSON 解析/查看脚本
│   └── cfg_ceval_ctrl_cap.json 容量对照配置
├── benchmark/             数据集（verify_stage2 默认相对包根解析）
│   ├── mcq_medium_clean.jsonl     主基准 500 题（核心）
│   ├── mcq_medium.jsonl          母集 500 题（编排器抽取子集用）
│   ├── mcq_medium_sub200_s20260811.jsonl  子集 200 题
│   ├── mcq_medium_orig100.jsonl 主基准种子 100 题（生成器输入）
│   ├── mcq_small.jsonl          早期开发小基准
│   └── ceval_*.jsonl            C-Eval 对照集
├── results_reference/     原实验已验证结果快照（供对比）
├── requirements.txt
├── README.md
└── 环境说明与复现指南.docx   （本包的正式文档，含 §12 参数总表 / §13 命令总表）
```

## 5. 复现方式

> ⚠️ **运行环境提示**：`run_experiments.sh` / `check_env.sh` 是 **bash 脚本**。Linux / macOS 自带 bash；**Windows 用户请务必用 Git Bash 或 WSL 运行**（原生 cmd / PowerShell 不支持 bash 脚本）。

### 第零步：环境自检（解压后第一步，强烈建议）

```bash
bash code/check_env.sh
```

脚本一次性检查：操作系统 / bash 可用性、python3 + numpy、Ollama 是否安装并常驻、三个 qwen2.5 模型（1.5b / 3b / 7b）是否已拉取。全部 `[OK]` 后再跑复现，可避免“跑到一半才发现缺依赖”。任一 `[缺]` 按提示补齐即可。

### 方式 A：一键编排（作者用，须改路径）

编辑 `code/run_light_repro.py` 顶部三个变量为本机路径：

```python
OUT  = Path(r"你的结果输出目录")
ROOT = Path(r"本包根目录")
PY   = r"你的 python 解释器路径"
```

然后运行：

```bash
python code/run_light_repro.py
```

将**串行**执行：① E3 k=5 同配置重跑（N=500）→ ② 换样本子集条件C（k=3, N=200）。自带 Ollama 探活、题级断点续跑。⚠️ 该脚本硬编码作者本机路径，**复现者须先改顶部 OUT/ROOT/PY 三变量**，或改用方式 C。

### 方式 B：手动单跑（更可控）

```bash
python code/verify_stage2.py --k 5 --n 500 --conn-w 1.0 \
  --benchmark benchmark/mcq_medium_clean.jsonl --temperature 0.0 \
  --out results --live results/my_E3_k5.json
```

`--out` 指定结果输出目录（**务必改成你自己的目录**，否则会写到作者机器路径）；`--live` 指定结果 json 名；断点续跑：`<--out>/tiers/<live_stem>_cw*.jsonl` 保留进度。

### 方式 C：全套串行复现（最省心，★推荐）

`code/run_experiments.sh` 已写好**全部 8 项实验**的精确启动命令（每项都显式传 `--out` 和相对包根的 `--benchmark`），在本包根目录执行即可一键跑完：

```bash
bash code/run_experiments.sh
```

跑完用 `python code/view_results.py results/<某项>.json` 逐条核对，与 `results_reference/` 原值及本文档 §6 一致。

## 6. 预期结果对照

| 实验 | 集体准确率 | 最强单体(7B) | 状态 |
|---|---|---|---|
| E3 k=5（N=500） | **≈ 0.942** | 0.836 | 已验证 |
| 条件C 复现（N=500） | 0.924 | 0.838 | 已验证 |
| 换子集条件C（N=200） | 待复现 | — | 验证非题集偶然 |

复现结果应与上表原值一致（主基准 temp=0 确定性，见 §7）。

## 7. 关键约束

- **用 `127.0.0.1` 而非 `localhost`**：Ollama 在部分环境将 localhost 解析为 IPv6 `::1` 会卡死。
- **CPU 推理并发 ≤ 2 客户端**：多开会互相饿死，必须串行。
- **确定性说明**：主基准 `temp=0` + 答案代码算 → 模型输出确定性，同配置多机结果应接近逐字节相同。因此「多机复现」验证的是**环境/可移植性稳健性**，而非统计显著性（统计靠换子集/换模型家族）。
- **solo 基线缓存陷阱**：单模型基线缓存在 `<--out>/solo_checkpoint.json`，仅以 `(题库, k, n)` 为键，**不含模型/种子**。换模型或换配置后若复用同一 `--out` 目录且同 k/n，会读到旧基线导致结果错误。**换模型/配置前先删除该文件**。

## 8. 贡献记录（署名依据）

每位复现者请填写下表，汇总后用于论文 author contributions（CRediT）：

| 姓名 | 机器规格 | 复现了哪项 | 提出/修正了什么 | 日期 |
|---|---|---|---|---|
| | | | | |
| | | | | |

**仅记录实际做了复现或修正代码/分析的贡献者**；无实质贡献者不挂名（杜绝 gift authorship）。

## 9. 模型连接机制与扩展

脚本通过**本地 Ollama 的 HTTP 接口**调用模型（无 SDK 依赖）：向 `http://127.0.0.1:11434/api/generate` 发 POST 请求（Python 标准库 `urllib.request`），响应文本即模型回答。Ollama 须在本机常驻。

- **分层架构**（写死在 `verify_stage2.py` 的 `cfg` 字典）：`l3=qwen2.5:1.5b`（按 k 重复）、`agg/l2=qwen2.5:3b`、`l1/orchestrator=qwen2.5:7b`、`verifier=qwen2.5:1.5b`。
- **更换/添加模型**：① `ollama pull <新标签>`；② 编辑 `cfg` 的 `models` 字典（或 `cfg_ceval_ctrl_cap.json`）把目标层指向新标签；③ 改连接主机/端口编辑 `cfg['ollama_url']`。
- **自检就绪**：脚本内置探活（轮询 `/api/tags`）；也可手动 `curl http://127.0.0.1:11434/api/tags` 确认返回 200。

## 10. 结果数据查看与解读

复现主交付物是单个 JSON（`--live` 指定）。包内已附解析脚本，直接打印关键指标：

```bash
python code/view_results.py results/my_E3_k5.json
```

JSON 顶层关键字段：

| 字段 | 含义 |
|---|---|
| `status` / `phase` | 运行态（running/done）与阶段（solo/pipeline/fit） |
| `models` | 各层模型标签 |
| `n_questions` | 题目数 |
| `node_acc` | 每个节点单独准确率（顺序：k 个 L3 → L2 → L1） |
| `best_single` | 最强单体准确率（主基准即 7B） |
| `committee0` | 纯多数投票基线（反制"只是平均/投票"指控） |
| `collective_acc` | 协作集体准确率，键为 Ẇ 档（如 `cw1.00`） |
| `points` | 每个 Ẇ 档一行，含 `G = collective − best_single`（经验涌现锚）、`superlinear`、`judgement` |

复现者核对：`collective_acc["cw1.00"] ≈ 0.942`（E3 k=5）且 `G > 0`，与 `results_reference/` 原值及本 README §6 对照表一致。

## 11. 实验参数总表（架构与全部参数）

完整表格见正式文档《环境说明与复现指南.docx》§12 / §13。要点速记：

| 参数 / 项 | 取值 |
|---|---|
| 分层架构 | L3 集群(×k, 1.5b) → 聚合(3b) → L2 副脑(3b) → L1 主脑(7b)，每层旁挂验证层(1.5b) |
| L3 专家数 k | 主基准 1(E1)/3(条件C)/5(E3)/7(E3)；对照 1 |
| 连接强度 Ẇ (--conn-w) | 1.0（定点） |
| 采样温度 | 0.0（确定性；--seed 仅在 temp>0 时才有效） |
| 题库 (--benchmark) | 主=mcq_medium_clean.jsonl / C-Eval=ceval_bandok_clean.jsonl / 英文=ceval_en.jsonl |
| 题数 (--n) | 500（主）/ 200（C-Eval 系列） |
| 评测 | 提取末选项字母，与 q["answer"] 精确比对（答案代码算，无外部标注） |
| 涌现判据 | 集体>最强单体 **且** 峰值在 Ẇ>0（否则即便数值超单体也不判涌现） |
| 消融 (--ablation) | none（主基准）/ demote（7B 降级进集群）/ remove（移除 7B） |

> 全部 8 项实验的精确启动命令见 `code/run_experiments.sh`（方式 C），无需手动拼参数。
