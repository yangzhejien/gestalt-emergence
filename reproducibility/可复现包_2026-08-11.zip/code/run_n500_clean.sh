#!/usr/bin/env bash
# N=500 主验 C (clean / none): 7B 主脑编排, 集体 vs 最强单体(7B solo) 显著性
# 单档 Ẇ=1.0 (headline tier); N=100 已证各档平坦, 单档足以做显著性检验
cd /d/方程验证
python scripts/verify_stage2.py \
  --benchmark benchmark/mcq_medium_clean.jsonl \
  --n 500 \
  --conn-w 1.0 \
  --live stage2_n500_clean_live.json \
  --ablation none
