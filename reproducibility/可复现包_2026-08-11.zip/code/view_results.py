# -*- coding: utf-8 -*-
"""查看复现结果 JSON 的关键指标（人类可读）。

复现输出为单份 JSON（verify_stage2.py 的 --live 参数指定，例如 results/my_E3_k5.json）。
本脚本把它顶层关键字段打印成表格，便于复现者快速核对涌现是否重现，
无需手动翻 JSON。

用法：
    python code/view_results.py results/my_E3_k5.json
    python code/view_results.py results/a.json results/b.json   # 可对比多条

关键字段：
    best_single   最强单体准确率（主基准即 7B 节点值）
    committee0    纯多数投票基线（反制“只是平均/投票”指控）
    collective_acc 协作集体准确率，键为 Ẇ 档（如 cw1.00）
    points        每个 Ẇ 档一行，含 G = collective - best_single（经验涌现锚）
    superlinear   G>0 即 True（集体超单体）
"""
import json
import sys
import os


def show(path):
    if not os.path.exists(path):
        print(f"[跳过] 文件不存在: {path}")
        return
    try:
        d = json.load(open(path, encoding="utf-8"))
    except Exception as e:
        print(f"[跳过] 解析失败 {path}: {e}")
        return

    print(f"文件: {path}")
    print(f"  状态/阶段 : {d.get('status')} / {d.get('phase')}   题数: {d.get('n_questions')}")
    models = d.get("models") or {}
    if models:
        print(f"  模型架构  : l3={models.get('l3')}  l2={models.get('l2')}  l1={models.get('orchestrator')}")
    print(f"  最强单体  : best_single = {d.get('best_single')}")
    print(f"  纯投票基线 : committee0  = {d.get('committee0')}")

    ca = d.get("collective_acc") or {}
    if isinstance(ca, dict):
        for k, v in ca.items():
            print(f"  集体准确率 : collective_acc[{k}] = {v}")
    elif ca is not None:
        print(f"  集体准确率 : collective_acc = {ca}")

    pts = d.get("points") or []
    if pts:
        p = pts[-1]
        g = p.get("G")
        sup = d.get("superlinear")
        if isinstance(sup, dict):
            sup_txt = f"beats_best={sup.get('beats_best')}  opt_Ẇ={sup.get('opt_conn_w')}"
        else:
            sup_txt = str(sup)
        print(f"  涌现锚 G  : collective - best_single = {g}   {sup_txt}")
        print(f"  judgement : {d.get('judgement')}")
    print()


def main():
    if len(sys.argv) < 2:
        print("用法: python code/view_results.py <live_json> [另一条用于对比]")
        sys.exit(1)
    for p in sys.argv[1:]:
        show(p)


if __name__ == "__main__":
    main()
