#!/usr/bin/env bash
# N=500 附验 D (demote): 3B 任主脑, 7B 降级为 L3 集群参与者
# 复用 C 的 solo 断点缓存(同 benchmark/n/k), 仅重算协作合成
cd /d/方程验证
python scripts/verify_stage2.py \
  --benchmark benchmark/mcq_medium_clean.jsonl \
  --n 500 \
  --conn-w 1.0 \
  --live stage2_n500_demote_live.json \
  --ablation demote
