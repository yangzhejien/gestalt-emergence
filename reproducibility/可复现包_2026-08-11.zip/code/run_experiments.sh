#!/usr/bin/env bash
# ============================================================
# 格式塔方程 —— 全套实验启动命令总表 (canonical 复现入口)
# ============================================================
# 用法: 在本包根目录执行   bash code/run_experiments.sh
# 前置: ① Ollama 已启动并常驻   ② 已拉取权重:
#         ollama pull qwen2.5:1.5b qwen2.5:3b qwen2.5:7b
# 设计: 所有命令都显式传 --out 指向你自己的结果目录;
#       --benchmark 相对本包根目录(脚本在 code/, ROOT=包根, 故基准在 benchmark/)。
# 说明: 主基准 temp=0 + 答案代码算 => 确定性, 同配置结果应近逐字节相同。
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"     # 包根目录
RES="$ROOT/results"                           # 你的结果输出目录
PY="python3"                                  # 改用你自己的 python3(需装 numpy)
mkdir -p "$RES"

run() {  # live文件名, 其余参数...
  local live="$1"; shift
  echo "===== $live ====="
  "$PY" "$ROOT/code/verify_stage2.py" --out "$RES" --live "$live" "$@"
}

# ——— 主基准涌现证据(核心主张) ———
run stage2_E1_k1.json         --benchmark benchmark/mcq_medium_clean.jsonl --n 500 --k 1 --conn-w 1.0
run stage2_condC_k3.json      --benchmark benchmark/mcq_medium_clean.jsonl --n 500 --k 3 --conn-w 1.0
run stage2_E3_k5.json         --benchmark benchmark/mcq_medium_clean.jsonl --n 500 --k 5 --conn-w 1.0
run stage2_E3_k7.json         --benchmark benchmark/mcq_medium_clean.jsonl --n 500 --k 7 --conn-w 1.0

# ——— C-Eval 硬基准反例(论文须正面解释) ———
run stage2_ceval_k1.json      --benchmark benchmark/ceval_bandok_clean.jsonl --n 200 --k 1 --conn-w 1.0
run stage2_ceval_k3.json      --benchmark benchmark/ceval_bandok_clean.jsonl --n 200 --k 3 --conn-w 1.0

# ——— 对照实验(排除纯容量 / 纯语言) ———
# 容量对照: L3 集群换为 3B(经 --config 覆盖), 主脑仍为 7B
run stage2_ceval_ctrl_cap_k1.json   --benchmark benchmark/ceval_bandok_clean.jsonl --n 200 --k 1 --conn-w 1.0 --seed 20260810 --config code/cfg_ceval_ctrl_cap.json
# 语言对照: 同一批题的英文翻译, 默认架构(1.5B 集群)
run stage2_ceval_ctrl_lang_k1.json  --benchmark benchmark/ceval_en.jsonl          --n 200 --k 1 --conn-w 1.0 --seed 20260810

echo ""
echo "ALL DONE -> 用以下命令核对每项结果:"
echo "  $PY $ROOT/code/view_results.py $RES/stage2_E3_k5.json"
echo "  (逐条核对 collective_acc[cw1.00] 与 results_reference/ 原值及本文档 §6 一致)"
