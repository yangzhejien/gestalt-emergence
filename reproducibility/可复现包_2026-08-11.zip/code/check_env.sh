#!/usr/bin/env bash
# ============================================================
# 格式塔方程复现 —— 环境自检 (对方解压后【第一步】先跑这个)
# ============================================================
# 用法 (在包根目录执行):
#     bash code/check_env.sh
# 作用: 一次性检查复现所需的全部外部依赖是否就绪,
#       避免跑到一半才发现缺 ollama / 没下模型 / 没装 numpy。
# 注意: 本脚本是 bash 脚本。Linux/macOS 自带 bash;
#       Windows 用户请用 Git Bash 或 WSL 运行(原生 cmd/powershell 不支持)。
# ============================================================
set -u
echo "===== 格式塔复现 · 环境自检 ====="

# 1) 操作系统 / bash 可用性提示
OS="$(uname -s 2>/dev/null || echo unknown)"
case "$OS" in
  MINGW*|MSYS*|CYGWIN*|Windows_NT)
    echo "[OS] 检测到 Windows。请确认你正用 Git Bash / WSL 运行本脚本(cmd/powershell 不支持 bash)。" ;;
  Linux*)  echo "[OS] Linux" ;;
  Darwin*) echo "[OS] macOS" ;;
  *)       echo "[OS] 未知系统($OS), 继续检查..." ;;
esac

# 2) python3 + numpy
if command -v python3 >/dev/null 2>&1; then
  if python3 -c "import numpy" >/dev/null 2>&1; then
    echo "[OK] python3 + numpy 可用"
  else
    echo "[缺] python3 存在, 但 numpy 未安装 -> 执行: pip install numpy"
  fi
else
  echo "[缺] 未找到 python3 -> 安装 Python 3.10+ 并加入 PATH"
fi

# 3) ollama 命令是否存在
if ! command -v ollama >/dev/null 2>&1; then
  echo "[缺] 未找到 ollama 命令 -> 到 https://ollama.com 安装并启动"
  echo "       启动后还需: ollama pull qwen2.5:1.5b qwen2.5:3b qwen2.5:7b"
  echo "===== 自检结束 (ollama 缺失, 后续检查跳过) ====="
  exit 0
fi
echo "[OK] ollama 命令存在"

# 4) ollama 服务是否已启动 (常驻) + 模型是否拉取
if ! ollama list >/tmp/gestalt_ollama_list.txt 2>/dev/null; then
  echo "[缺] Ollama 服务未响应 -> 请先启动 ollama 并使其常驻(后台运行), 再执行本脚本"
  echo "===== 自检结束 (服务未启动, 模型检查跳过) ====="
  exit 0
fi
echo "[OK] Ollama 服务已在 127.0.0.1:11434 响应"

for m in qwen2.5:1.5b qwen2.5:3b qwen2.5:7b; do
  if grep -q "$m" /tmp/gestalt_ollama_list.txt; then
    echo "[OK] 模型已拉取: $m"
  else
    echo "[缺] 模型未拉取: $m -> 执行: ollama pull $m"
  fi
done

echo "===== 自检结束 ====="
echo "若以上全部 [OK], 即可运行复现:  bash code/run_experiments.sh"
echo "若仍有 [缺], 先按提示补齐依赖再跑; 跑前请务必让 ollama 常驻且模型已下载。"
